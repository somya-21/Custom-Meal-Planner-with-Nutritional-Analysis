document.addEventListener('DOMContentLoaded', function() {
    const mealForm = document.getElementById('mealForm');
    const mealPlanDiv = document.getElementById('mealPlan');
    const nutritionSummaryDiv = document.getElementById('nutritionSummary');

    // Handle form submission
    mealForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const mealData = {
            name: document.getElementById('mealName').value,
            calories: parseInt(document.getElementById('calories').value),
            protein: parseFloat(document.getElementById('protein').value),
            carbs: parseFloat(document.getElementById('carbs').value),
            fats: parseFloat(document.getElementById('fats').value)
        };

        try {
            const response = await fetch('/api/meals', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(mealData)
            });

            if (response.ok) {
                alert('Meal added successfully!');
                mealForm.reset();
                loadMeals();
            } else {
                alert('Error adding meal');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error adding meal');
        }
    });

    // Load meals
    async function loadMeals() {
        try {
            const response = await fetch('/api/meals');
            const meals = await response.json();
            displayMeals(meals);
            updateNutritionSummary(meals);
        } catch (error) {
            console.error('Error:', error);
        }
    }

    // Display meals in the meal plan
    function displayMeals(meals) {
        mealPlanDiv.innerHTML = '';
        meals.forEach(meal => {
            const mealElement = document.createElement('div');
            mealElement.className = 'meal-item';
            mealElement.innerHTML = `
                <h6>${meal.name}</h6>
                <p>Calories: ${meal.calories} kcal</p>
                <small>
                    Protein: ${meal.protein}g | 
                    Carbs: ${meal.carbs}g | 
                    Fats: ${meal.fats}g
                </small>
            `;
            mealPlanDiv.appendChild(mealElement);
        });
    }

    // Update nutrition summary
    function updateNutritionSummary(meals) {
        const totalNutrition = meals.reduce((acc, meal) => {
            return {
                calories: acc.calories + meal.calories,
                protein: acc.protein + meal.protein,
                carbs: acc.carbs + meal.carbs,
                fats: acc.fats + meal.fats
            };
        }, { calories: 0, protein: 0, carbs: 0, fats: 0 });

        nutritionSummaryDiv.innerHTML = `
            <div class="row">
                <div class="col-md-3">
                    <strong>Calories:</strong><br>${totalNutrition.calories} kcal
                </div>
                <div class="col-md-3">
                    <strong>Protein:</strong><br>${totalNutrition.protein.toFixed(1)}g
                </div>
                <div class="col-md-3">
                    <strong>Carbs:</strong><br>${totalNutrition.carbs.toFixed(1)}g
                </div>
                <div class="col-md-3">
                    <strong>Fats:</strong><br>${totalNutrition.fats.toFixed(1)}g
                </div>
            </div>
        `;
    }

    // Initial load
    loadMeals();
});
