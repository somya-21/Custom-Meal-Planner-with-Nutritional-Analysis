# Custom Meal Planner with Nutritional Analysis

A web application for planning meals and tracking nutritional information.

## Features
- Create and manage meal plans
- View nutritional information for meals
- Search for recipes
- Track daily nutritional goals

## Setup
1. Create a virtual environment:
```
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```
pip install -r requirements.txt
```

3. Run the application:
```
python app.py
```

## Technologies Used
- Flask (Backend)
- SQLAlchemy (Database)
- HTML/CSS/JavaScript (Frontend)
- Bootstrap (UI Framework)
