from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mealplanner.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class Meal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    calories = db.Column(db.Integer)
    protein = db.Column(db.Float)
    carbs = db.Column(db.Float)
    fats = db.Column(db.Float)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

class MealPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, nullable=False)
    meal_id = db.Column(db.Integer, db.ForeignKey('meal.id'), nullable=False)
    meal_type = db.Column(db.String(20), nullable=False)  # breakfast, lunch, dinner, snack

with app.app_context():
    db.create_all()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/meals', methods=['GET', 'POST'])
def handle_meals():
    if request.method == 'POST':
        data = request.json
        new_meal = Meal(
            name=data['name'],
            calories=data['calories'],
            protein=data['protein'],
            carbs=data['carbs'],
            fats=data['fats']
        )
        db.session.add(new_meal)
        db.session.commit()
        return jsonify({'message': 'Meal added successfully'})
    
    meals = Meal.query.all()
    return jsonify([{
        'id': meal.id,
        'name': meal.name,
        'calories': meal.calories,
        'protein': meal.protein,
        'carbs': meal.carbs,
        'fats': meal.fats,
        'date': meal.date.strftime('%Y-%m-%d')
    } for meal in meals])

@app.route('/api/mealplan', methods=['GET', 'POST'])
def handle_meal_plan():
    if request.method == 'POST':
        data = request.json
        new_plan = MealPlan(
            date=datetime.strptime(data['date'], '%Y-%m-%d'),
            meal_id=data['meal_id'],
            meal_type=data['meal_type']
        )
        db.session.add(new_plan)
        db.session.commit()
        return jsonify({'message': 'Meal plan added successfully'})
    
    plans = MealPlan.query.all()
    return jsonify([{
        'id': plan.id,
        'date': plan.date.strftime('%Y-%m-%d'),
        'meal_id': plan.meal_id,
        'meal_type': plan.meal_type
    } for plan in plans])

if __name__ == '__main__':
    app.run(debug=True)
